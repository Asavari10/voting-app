package com.voting.votingapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VotingappApplication {

	public static void main(String[] args) {
		SpringApplication.run(VotingappApplication.class, args);
	}

}
