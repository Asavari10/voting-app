package com.voting.votingapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VotingappApplicationTests {

	@Test
	void contextLoads() {
	}

}
